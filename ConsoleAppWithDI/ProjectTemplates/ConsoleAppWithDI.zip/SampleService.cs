﻿namespace $safeprojectname$
{
    public interface ISampleService
    {
        void SayHello();
    }

    public class SampleService : ISampleService
    {
        public void SayHello()
        {
            System.Console.WriteLine("Olá Mundo!! Hello World!! Hola mundo!!");
        }
    }
}
