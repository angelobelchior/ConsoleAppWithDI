﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace $safeprojectname$
{
    public class Startup
    {
        public static void Main(string[] args)
        {
            var environmentVariable = Environment.GetEnvironmentVariable("NETCORE_ENVIRONMENT");
            var isDevelopment = string.IsNullOrEmpty(environmentVariable) || environmentVariable.ToLower() == "development";

            var builder = new ConfigurationBuilder();
            builder.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
            
            //if (isDevelopment)
            //    builder.AddUserSecrets<Startup>();

            var services = new ServiceCollection();

            //Configure Services
            services.AddSingleton<ISampleService, SampleService>();

            services.AddSingleton<IProgram, Program>();
            services.AddSingleton<IConfiguration>(i => builder.Build());
            var serviceProvider = services.BuildServiceProvider();
            serviceProvider.GetService<IProgram>().Run(args);
        }
    }
}
