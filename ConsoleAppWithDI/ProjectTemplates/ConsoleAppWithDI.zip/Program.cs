﻿namespace $safeprojectname$
{
    public interface IProgram
    {
        void Run(string[] args);
    }

    public class Program : IProgram
    {
        private readonly ISampleService _sampleService;
        public Program(ISampleService sampleService)
            => this._sampleService = sampleService;

        public void Run(string[] args)
            => this._sampleService.SayHello();
    }
}
